/**
 * NoProc Content Script
 * Bridging the Dashboard with the Extension
 */

// 1. Listen for commands FROM the Website (to control music)
window.addEventListener('NOPROC_MUSIC_CONTROL', (event) => {
    const action = event.detail.action;
    chrome.runtime.sendMessage({
        type: 'MUSIC_CONTROL',
        action: action
    });
});

// 2. Listen for metadata FROM the Background (to update UI)
chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'MUSIC_METADATA') {
        window.dispatchEvent(new CustomEvent('NOPROC_MUSIC_METADATA', {
            detail: message.metadata
        }));
    }
});

console.log('[NoProc Extension] Content script bridge active.');
