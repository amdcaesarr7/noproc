chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'PING') {
        sendResponse({ status: 'ok' });
        return true;
    }
    if (request.type === 'MUSIC_CONTROL') {
        chrome.tabs.query({}, (tabs) => {
            tabs.forEach(tab => {
                const isMusicSite = tab.url && (
                    tab.url.includes('music.youtube.com') ||
                    tab.url.includes('youtube.com') ||
                    tab.url.includes('spotify.com') ||
                    tab.audible
                );

                if (isMusicSite) {
                    chrome.scripting.executeScript({
                        target: { tabId: tab.id },
                        func: (action) => {
                            const media = document.querySelector('video, audio');
                            if (action === 'playPause' && media) {
                                if (media.paused) media.play();
                                else media.pause();
                            } else if (action === 'next' && navigator.mediaSession) {
                                navigator.mediaSession.metadata?.nextTrack?.() || document.querySelector('.next-button, .ytp-next-button')?.click();
                            } else if (action === 'previous' && navigator.mediaSession) {
                                navigator.mediaSession.metadata?.previousTrack?.() || document.querySelector('.previous-button, .ytp-prev-button')?.click();
                            }
                        },
                        args: [request.action]
                    });
                }
            });
        });
    }
});

// Periodic metadata extraction
setInterval(() => {
    chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
            const isMusicSite = tab.url && (
                tab.url.includes('music.youtube.com') ||
                tab.url.includes('youtube.com') ||
                tab.url.includes('spotify.com') ||
                tab.audible
            );

            if (isMusicSite) {
                chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    func: () => {
                        if (navigator.mediaSession && navigator.mediaSession.metadata) {
                            const meta = navigator.mediaSession.metadata;
                            return {
                                title: meta.title,
                                artist: meta.artist,
                                album: meta.album,
                                artwork: meta.artwork && meta.artwork.length > 0 ? meta.artwork[meta.artwork.length - 1].src : null
                            };
                        }
                        return null;
                    }
                }, (results) => {
                    if (results && results[0] && results[0].result) {
                        // Broadcast to all NoProc dashboard tabs (file:// and others)
                        chrome.tabs.query({}, (allTabs) => {
                            allTabs.forEach(t => {
                                if (t.url && t.url.includes('NoProc/index.html')) {
                                    chrome.tabs.sendMessage(t.id, {
                                        type: 'MUSIC_METADATA',
                                        metadata: results[0].result
                                    });
                                }
                            });
                        });
                    }
                });
            }
        });
    });
}, 3000);
